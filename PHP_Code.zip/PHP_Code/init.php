<?php


	$AppName="Total Video Downloader";
	$AppHeading="Best Free HD fast video downloader ";
	$AppURL="http://videodownloader.shivjagar.co.in/";
	$ShowTestLinks=true;

?>